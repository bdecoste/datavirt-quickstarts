mvn install -Dvdb="portfolio" -Dsql="select * from product" -Dusername="admin" -
Dpassword="P@ssword1"
